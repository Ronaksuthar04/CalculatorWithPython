from tkinter import *
from PIL import Image,ImageTk

# --------------Basic code------------------------
gui=Tk()
gui.title('Calculator - By Ronak Suthar')
image=Image.open('calculator.png')
icon=ImageTk.PhotoImage(image)
gui.iconphoto(True,icon)

inpTxt=''

btnlist=['1','2','3','+','4','5','6','-','7','8','9','*','0','00','.','/']

# -------------Functions-----------------------------

# Display auto adjust function -----------------------
def winUpdate():
    gui.update_idletasks()
    winH=gui.winfo_reqheight()
    winW=400
    gui.geometry(f'410x{winH}')
    gui.minsize(410,winW)

#  Main functions --------------------------------------------------

def func(txt):
    global inpTxt
    inpTxt+=txt
    display.config(text=inpTxt)
    winUpdate()

def clear():
    global inpTxt
    inpTxt=''
    display.config(text=inpTxt)
    winUpdate()


def backspace():
    global inpTxt
    inpTxt=inpTxt[0:-1]
    display.config(text=inpTxt)
    winUpdate()

def result():
    global inpTxt
    try:
        result=eval(inpTxt)
        display.config(text=result)
        inpTxt=''
    except :
        display.config(text='Not a Math expression!!')
    finally:
        winUpdate()

# ------------------Main Body--------------------
# frames-------------

fr=Frame(gui)
fr.pack(side=TOP,fill=X)

fr1=Frame(gui,borderwidth=1,relief=RAISED)
fr1.pack(side=TOP,fill=BOTH)

fr2=Frame(gui,borderwidth=1,relief=RAISED,bg='gray')
fr2.pack(side=TOP,fill=BOTH)

# display---------------

display=Message(fr,text=inpTxt,width=370,font='arial 20',bg='lightgray',borderwidth=1,relief=SUNKEN)
display.pack(side=TOP,fill=X)

# Basic buttons-----------------

for i,numtxt in enumerate(btnlist):
    btn=Button(fr1,text=numtxt,font='lucida 30',activebackground='lightgray',command= lambda txt=numtxt : func(txt),width=4)
    btn.grid(row=(i)//4,column=(i)%4)

# Speacial buttons----------------

btn=Button(fr2,text='C',font='lucida 30',command=clear,width=4,bg='lightgray')
btn.grid(row=0,column=0)
btn=Button(fr2,text='<=',font='lucida 30',command= backspace,width=4,bg='silver')
btn.grid(row=0,column=1)
btn=Button(fr2,text='=',font='lucida 30',command= result,width=4,bg='orange')
btn.grid(row=0,column=2)
btn=Button(fr2,text='X',font='lucida 30',command=quit,width=4,bg='red')
btn.grid(row=0,column=3)

gui.mainloop()